# Otherwise present user with bootstrap script to stdout
exec gomplate -f /templates/bootstrap
