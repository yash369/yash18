These are a collection of [`gomplate`](https://gomplate.hairyhenderson.ca) formatted templates

